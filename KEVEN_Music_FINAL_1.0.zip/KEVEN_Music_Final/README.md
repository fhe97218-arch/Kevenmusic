# KEVEN Music 🎧

Proyecto base/final de arquitectura para una app musical Flutter.

## Incluye

- Home, búsqueda y biblioteca.
- Estado global con Provider.
- Modelo de canciones.
- Capa de catálogo separada.
- Capa de audio separada.
- SQLite para favoritos, playlists e historial.
- Dependencias preparadas para `just_audio` y `audio_service`.
- Estructura lista para conectar un proveedor de catálogo/audio autorizado.

## Importante

La implementación actual usa un catálogo de demostración y un servicio de audio placeholder. El proveedor real debe tener autorización para ofrecer el contenido y su reproducción. No se incluyen extractores, bypass de anuncios ni mecanismos para eludir restricciones de plataformas.

## Ejecutar

```bash
flutter pub get
flutter run
```

## Generar APK

```bash
flutter build apk --release
```

El APK resultante estará normalmente en:

`build/app/outputs/flutter-apk/app-release.apk`

## GitHub

```bash
git init
git add .
git commit -m "KEVEN Music 1.0.0"
git branch -M main
git remote add origin TU_REPOSITORIO_GITHUB
git push -u origin main
```

## Próxima integración

Reemplazar `DemoMetadataService` por un adaptador de API de catálogo autorizado y `PlaceholderAudioService` por el adaptador del proveedor de audio autorizado. La UI no debería necesitar cambios.
