import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state/app_state.dart';
import 'screens/home_screen.dart';
import 'screens/search_screen.dart';
import 'screens/library_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState(),
      child: const KevenMusicApp(),
    ),
  );
}

class KevenMusicApp extends StatelessWidget {
  const KevenMusicApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KEVEN Music',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF080808),
        colorSchemeSeed: Colors.deepPurple,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomeScreen(), SearchScreen(), LibraryScreen()];

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(child: pages[index]),
            if (state.currentSong != null) const MiniPlayer(),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Inicio'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Buscar'),
          NavigationDestination(icon: Icon(Icons.library_music_outlined), selectedIcon: Icon(Icons.library_music), label: 'Biblioteca'),
        ],
      ),
    );
  }
}

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final song = state.currentSong!;
    return Material(
      color: const Color(0xFF171717),
      child: InkWell(
        onTap: () => showModalBottomSheet(
          context: context,
          backgroundColor: const Color(0xFF101010),
          builder: (_) => const PlayerSheet(),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              const CircleAvatar(child: Icon(Icons.music_note)),
              const SizedBox(width: 12),
              Expanded(child: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
              IconButton(
                onPressed: state.togglePlay,
                icon: Icon(state.playing ? Icons.pause_circle_filled : Icons.play_circle_filled),
              ),
              IconButton(onPressed: state.next, icon: const Icon(Icons.skip_next)),
            ],
          ),
        ),
      ),
    );
  }
}

class PlayerSheet extends StatelessWidget {
  const PlayerSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final song = state.currentSong;
    if (song == null) return const SizedBox.shrink();
    return SizedBox(
      height: 430,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 12),
            Container(width: 45, height: 5, decoration: BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.circular(8))),
            const SizedBox(height: 30),
            const CircleAvatar(radius: 95, child: Icon(Icons.album, size: 100)),
            const SizedBox(height: 25),
            Text(song.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text(song.artist, style: TextStyle(color: Colors.grey.shade400)),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: state.previous, icon: const Icon(Icons.skip_previous, size: 38)),
                IconButton(onPressed: state.togglePlay, icon: Icon(state.playing ? Icons.pause_circle : Icons.play_circle, size: 70)),
                IconButton(onPressed: state.next, icon: const Icon(Icons.skip_next, size: 38)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
