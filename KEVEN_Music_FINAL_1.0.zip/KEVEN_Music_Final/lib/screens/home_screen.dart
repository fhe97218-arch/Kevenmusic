import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../models/song.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('KEVEN MUSIC', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text('Descubre música de todo el mundo.', style: TextStyle(color: Colors.grey.shade400)),
        const SizedBox(height: 28),
        const Text('🔥 Tendencias', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SongCard(song: const Song(id: 'home1', title: 'Descubrimiento Global', artist: 'KEVEN Music')),
        SongCard(song: const Song(id: 'home2', title: 'World Mix', artist: 'Artistas del mundo')),
        const SizedBox(height: 22),
        const Text('🌎 Explorar', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: ['Pop', 'Rock', 'Rap', 'K-Pop', 'Latina', 'Jazz', 'Electrónica'].map((x) => Chip(label: Text(x))).toList()),
      ],
    );
  }
}

class SongCard extends StatelessWidget {
  final Song song;
  const SongCard({super.key, required this.song});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.music_note)),
        title: Text(song.title),
        subtitle: Text(song.artist),
        trailing: IconButton(
          icon: const Icon(Icons.play_arrow),
          onPressed: () => context.read<AppState>().play(song),
        ),
      ),
    );
  }
}
