import 'package:flutter/material.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        Text('Biblioteca', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        SizedBox(height: 20),
        ListTile(leading: Icon(Icons.favorite), title: Text('Favoritos'), subtitle: Text('Tus canciones guardadas')),
        ListTile(leading: Icon(Icons.queue_music), title: Text('Playlists'), subtitle: Text('Tus listas de reproducción')),
        ListTile(leading: Icon(Icons.history), title: Text('Historial'), subtitle: Text('Reproducciones recientes')),
        ListTile(leading: Icon(Icons.download), title: Text('Offline'), subtitle: Text('Contenido permitido para uso sin conexión')),
      ],
    );
  }
}
