import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final controller = TextEditingController();
  Timer? timer;

  void onChanged(String value) {
    timer?.cancel();
    timer = Timer(const Duration(milliseconds: 350), () {
      if (mounted) context.read<AppState>().search(value);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Buscar', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        const SizedBox(height: 18),
        TextField(
          controller: controller,
          onChanged: onChanged,
          decoration: InputDecoration(
            hintText: 'Canción, artista o álbum...',
            prefixIcon: const Icon(Icons.search),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
          ),
        ),
        const SizedBox(height: 18),
        ...state.results.map((song) => ListTile(
          leading: const CircleAvatar(child: Icon(Icons.album)),
          title: Text(song.title),
          subtitle: Text(song.artist),
          trailing: IconButton(onPressed: () => state.play(song), icon: const Icon(Icons.play_arrow)),
        )),
      ],
    );
  }
}
