import '../models/song.dart';

abstract class AuthorizedAudioService {
  Future<void> play(Song song);
  Future<void> pause();
  Future<void> stop();
}

/// Punto de integración para un proveedor que entregue reproducción
/// legalmente autorizada. No realiza extracción ni bypass de plataformas.
class PlaceholderAudioService implements AuthorizedAudioService {
  @override
  Future<void> play(Song song) async {}

  @override
  Future<void> pause() async {}

  @override
  Future<void> stop() async {}
}
