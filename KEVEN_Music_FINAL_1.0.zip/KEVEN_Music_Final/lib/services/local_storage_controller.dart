import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class LocalStorageController {
  static Database? _db;

  static Future<Database> get database async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'keven_music.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('CREATE TABLE favorites (id TEXT PRIMARY KEY, title TEXT, artist TEXT)');
        await db.execute('CREATE TABLE playlists (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)');
        await db.execute('CREATE TABLE history (id TEXT PRIMARY KEY, title TEXT, artist TEXT, played_at INTEGER)');
      },
    );
    return _db!;
  }
}
