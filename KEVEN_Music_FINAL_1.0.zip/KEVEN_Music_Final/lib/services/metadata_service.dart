import '../models/song.dart';

abstract class MetadataService {
  Future<List<Song>> search(String query);
}

class DemoMetadataService implements MetadataService {
  @override
  Future<List<Song>> search(String query) async {
    await Future<void>.delayed(const Duration(milliseconds: 250));
    if (query.trim().isEmpty) return [];
    return [
      Song(id: 'demo-1', title: '$query — resultado 1', artist: 'KEVEN Music'),
      Song(id: 'demo-2', title: '$query — resultado 2', artist: 'Artista Global'),
      Song(id: 'demo-3', title: '$query — resultado 3', artist: 'Descubrimiento'),
    ];
  }
}
