import 'package:flutter/foundation.dart';
import '../models/song.dart';
import '../services/audio_service.dart';
import '../services/metadata_service.dart';

class AppState extends ChangeNotifier {
  final MetadataService metadata = DemoMetadataService();
  final AuthorizedAudioService audio = PlaceholderAudioService();

  Song? currentSong;
  bool playing = false;
  List<Song> results = [];

  Future<void> search(String query) async {
    results = await metadata.search(query);
    notifyListeners();
  }

  Future<void> play(Song song) async {
    currentSong = song;
    playing = true;
    await audio.play(song);
    notifyListeners();
  }

  Future<void> togglePlay() async {
    if (currentSong == null) return;
    playing = !playing;
    if (playing) {
      await audio.play(currentSong!);
    } else {
      await audio.pause();
    }
    notifyListeners();
  }

  Future<void> next() async {}
  Future<void> previous() async {}
}
